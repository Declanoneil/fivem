# esx_crafting - Crafting script for ESX Framework

## Introduction

> I made this resource a while ago, some dutch servers were using it so I thought I might as well release it to the public. This resource allows you to craft certain items by playing a game (https://codepen.io/marctannous/pen/qONmob) and also has a crafting points system (which you can edit).

## Support

> I don't really wanna deal with support privately anymore, I will respond on the FiveM forums sometimes but not on discord anymore.

## Installation

> Put the 'esx_crafting' in your resource folder. **Pay ATTENTION: You have to call the resource 'esx_crafting' in order for the javascript to work!!!**

> Start the resource in your server.cfg

> Upload the esx_crafting.sql to your database

> Voila, you can edit the config however you like, I added some comments that explain how the config works.

## Credits

> I also have to give credits ofcourse to Marc Tannous (https://codepen.io/marctannous) for the codepen.io code.

Hope you all enjoy the resource <3

